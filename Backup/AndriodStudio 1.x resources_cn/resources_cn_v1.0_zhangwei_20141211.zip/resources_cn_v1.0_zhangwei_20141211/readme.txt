﻿Android Studio 汉化补丁 for v1.0 rc4

下载地址：http://www.android-studio.org/index.php/chinese
关注更新：http://ask.android-studio.org/?/article/13
作者主页：http://ask.android-studio.org/?/people/wellchang

用法及声明: 
适用于Android Studio v1.0 rc4 （对于早期版本的STUDIO，请使用早期的补丁）
关闭当前运行的Android Studio程序
备份android studio安装目录下lib/resources_en.jar
对下载的包文件进行解压，用新的resources_en.jar替换安装目录下的lib/resources_en.jar
作者：wellchang (如果觉得补丁有帮助，请在“Android Studio 中文组”网站为其投票，以示支持)
发布：Android Studio 中文组